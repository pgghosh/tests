package com.example.silverbars.model;

public enum OrderType {
    BUY,SELL
}
