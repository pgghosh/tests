package com.example.silverbars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SilverbarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SilverbarsApplication.class, args);
	}
}
